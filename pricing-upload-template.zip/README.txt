PRICING UPLOAD TEMPLATE

selling.csv contains 32 starter rows: the same four price types and eight quantity bands as New Card in Edit Pricing, in the same order. The existing uploader requires one row per price type and quantity band, rather than a wide table.

Fill sku (SKU), product (Card Product Name), sellingPrice, source and sourceDate on each selling row. Repeat the SKU and product for all its rows. Copy the 32-row block for each additional card. Remove unused rows; do not upload blank starter rows. Selling prices must be positive numbers.

Edit Pricing QTY columns map to these inclusive ranges:
QTY 0: 1-4999
QTY 5,000: 5000-9999
QTY 10,000: 10000-24999
QTY 25,000: 25000-49999
QTY 50,000: 50000-99999
QTY 100,000: 100000-249999
QTY 250,000: 250000-499999
QTY 500,000: 500000 with a blank quantityMax (no upper limit)
Keep any different existing bands when updating an existing card.

Keep both CSV files at the ZIP root with the exact headers provided. All columns are required by the existing uploader. Use UTF-8, plain numbers, USD per Each, a source description and sourceDate in YYYY-MM-DD format. Only quantityMax may be blank in completed rows. Source dates record provenance; they do not schedule future prices. Future dates and overlapping schedules are rejected.

costs.csv is header-only. Add the costs you want to retain for every updated SKU. For one fixed cost, use quantityMin=1 and leave quantityMax blank. Supplier cost bands are optional. Allowed costBasis values: oppiot, supplier_purchase, average_cost, last_purchase. The admin reads the cost basis from this file. Use one cost basis per ZIP. Cost prices may be zero but not negative. Omit cost rows only when cost is unavailable; margins will then be unavailable.

Updating included SKUs replaces ALL their selling and cost records. Include every selling price and cost that should remain for each updated SKU. Other SKUs remain unchanged. Uploaded prices become public after publishing.

EMEA Strategic Account (MAF) is the supported display-name alias for the existing Magic Planet price type. This template is an interchange format, not a native NetSuite export. Map NetSuite fields explicitly; Base is not automatically EMEA Premium.
