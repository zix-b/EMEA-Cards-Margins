Put these two CSV files at the ZIP root. UTF-8, plain numbers, USD per Each.
One row per SKU/price type/quantity band/date. sourceDate is YYYY-MM-DD.
quantityMin is a positive whole number; blank quantityMax means no upper limit.
For one fixed unit cost, use quantityMin=1 and leave quantityMax blank.
Blank or unavailable cost: omit its cost row; a numeric zero is an explicit zero cost.
costBasis: oppiot, supplier_purchase, average_cost, or last_purchase.
Map NetSuite labels explicitly; Base is not automatically assumed to mean EMEA Premium.
Allowed price types: Standard Price (EMEA License); Base Price (EMEA Premium); Distributor Price (EMEA); EMEA Strategic Account (Magic Planet)
This is an interchange template, not a verified native NetSuite export format.

Original website: upload one current schedule. Source dates are provenance, not automatic activation. Future dates and overlapping schedules are rejected.
Include complete selling and cost records for each updated SKU. Prices are public after publication.
